class ventanaC:Iventana{

    public string tipoventana(){
        return "Ventana corrediza";
    }
}