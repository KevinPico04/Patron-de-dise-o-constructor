class ventanasF:Iventana{

    public string tipoventana(){
        return "Ventana fija ";
    }
   
}