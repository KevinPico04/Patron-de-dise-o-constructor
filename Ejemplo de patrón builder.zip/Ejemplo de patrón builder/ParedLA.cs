class ParedLA:Ipared{

    public string materialpared(){
        
        return "Paredes de ladrillo";
    }
}