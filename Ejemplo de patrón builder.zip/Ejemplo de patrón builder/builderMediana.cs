class builderMediana:Ibuilder{

    private Casa casa2 = new Casa();

    public void construirpared()
    {
        casa2.crearparedes(new ParedLA());
    }
    public void construirpisos()
    {
        casa2.crearpisos(new mediana());
    }
    public void construirventana()
    {
        casa2.crearventanas(new ventanaC());
    }
    public Casa obtenercasa(){
        return casa2;
    }
}
    