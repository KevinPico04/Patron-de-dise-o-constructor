class Director{


    public void construye(Ibuilder pConstructor){

        pConstructor.construirpared();
        pConstructor.construirpisos();
        pConstructor.construirventana();
    }
}