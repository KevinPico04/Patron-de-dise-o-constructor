interface Ipisos{

    string cantidadpisos();
}