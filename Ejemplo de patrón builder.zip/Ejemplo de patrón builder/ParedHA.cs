class ParedHA:Ipared{

    public string materialpared(){
        return "Paredes de hormigón armado";
    }
}