class builderGrande:Ibuilder{

    private Casa casa1 = new Casa();

    public void construirpared()
    {
        casa1.crearparedes(new ParedHA());
    }
    public void construirpisos()
    {
        casa1.crearpisos(new grande());
    }
    public void construirventana()
    {
        casa1.crearventanas(new ventanal());
    }
    public Casa obtenercasa(){
        return casa1;
    }
    
}