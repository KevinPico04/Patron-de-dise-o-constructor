class ParedM:Ipared{

    public string materialpared(){
        return "Paredes de madera";
    }
}