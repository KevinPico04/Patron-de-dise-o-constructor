class ventanal:Iventana{

    public string tipoventana(){
        return "Ventanal";
    }
    
}