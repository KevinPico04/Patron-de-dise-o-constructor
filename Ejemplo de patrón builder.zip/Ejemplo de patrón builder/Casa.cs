class Casa{
    
    private Ipared paredes;
    private  Ipisos pisos;
    private  Iventana ventanas;
    public void crearparedes(Ipared pPared){
        paredes= pPared;
        Console.WriteLine("se han creado {0}", paredes.materialpared());

    }

    public void crearpisos(Ipisos pPisos){
        pisos= pPisos;
        Console.WriteLine("se hizo una {0} ", pisos.cantidadpisos());

    }

    public void crearventanas(Iventana pVentana){
        ventanas= pVentana;
         Console.WriteLine("se puso {0} ", ventanas.tipoventana());
    }

    

    public void Mostrarcasa(){

        Console.WriteLine("Tu casa tiene {0}, {1}, {2}", paredes.materialpared(), pisos.cantidadpisos(), ventanas.tipoventana());
    }



}