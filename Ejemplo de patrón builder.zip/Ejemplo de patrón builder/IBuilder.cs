interface Ibuilder{

    void construirpared();
    void construirventana();
    void construirpisos();

}