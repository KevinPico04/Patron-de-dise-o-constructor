﻿internal class Program
{
    private static void Main(string[] args)
    {
        Director miDirector = new Director();

        // Construimos una casa grande
        builderGrande Grande = new builderGrande();
        miDirector.construye(Grande);

        //Obtenemos la casa
        Casa casa1 = Grande.obtenercasa();
        casa1.Mostrarcasa();

        Console.WriteLine("----------------------------------------------------------------------------------------------------------------------");
        

        //construimos una casa mediana
        builderMediana Mediana = new builderMediana();
        miDirector.construye(Mediana);

        //Obtenemos la casa
        Casa casa2 = Mediana.obtenercasa();
        casa2.Mostrarcasa();

        Console.WriteLine("----------------------------------------------------------------------------------------------------------------------");


        //construimos una casa pequeña 
        builderPequeña Pequeña = new builderPequeña();
        miDirector.construye(Pequeña);

        //Obtenemos la casa
        Casa casa3 = Pequeña.obtenercasa();
        casa3.Mostrarcasa();

        Console.WriteLine("----------------------------------------------------------------------------------------------------------------------");
    }
}