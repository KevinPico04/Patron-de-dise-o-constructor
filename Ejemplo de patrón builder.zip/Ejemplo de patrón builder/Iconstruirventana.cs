interface Iventana{

    string tipoventana();
}