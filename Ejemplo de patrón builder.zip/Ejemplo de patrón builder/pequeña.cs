class pequeña:Ipisos{
    
    public string cantidadpisos(){

        return "casa de 1 piso";
    }
}