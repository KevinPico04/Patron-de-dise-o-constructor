class builderPequeña:Ibuilder{

    private Casa casa3 = new Casa();

    public void construirpared()
    {
        casa3.crearparedes(new ParedM());
    }
    public void construirpisos()
    {
        casa3.crearpisos(new pequeña());
    }
    public void construirventana()
    {
        casa3.crearventanas(new ventanasF());
    }
    public Casa obtenercasa(){
        return casa3;
    }
}
    