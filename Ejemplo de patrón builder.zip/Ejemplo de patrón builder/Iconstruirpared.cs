interface Ipared{

    string materialpared();
}
