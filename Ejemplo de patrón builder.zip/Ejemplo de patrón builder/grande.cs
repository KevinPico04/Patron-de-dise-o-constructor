class grande:Ipisos{
    
    public string cantidadpisos(){

        return "casa de 3 pisos";
    }
}