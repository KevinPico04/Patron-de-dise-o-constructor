class mediana:Ipisos{
    
    public string cantidadpisos(){

        return "casa de 2 pisos";
    }
}